import { expect, test } from "bun:test";
import { launcherCapabilityProbeRequired, setupIntegrationPlan, setupProxyIsReady } from "../src/setup";

const config = {
  mode: "browser-only" as const,
  releaseVersion: "0.2.0",
};

test("setup accepts only a matching daemon that is ready for new Codex turns", () => {
  const ready = {
    service: "codex-chatgpt-web",
    status: "ok",
    mode: "browser-only",
    version: "0.2.0",
    accepting_turns: true,
  };

  expect(setupProxyIsReady(ready, config)).toBe(true);
  expect(setupProxyIsReady({ ...ready, accepting_turns: false }, config)).toBe(false);
  expect(setupProxyIsReady({ ...ready, status: "degraded" }, config)).toBe(false);
  expect(setupProxyIsReady({ ...ready, version: "0.1.16" }, config)).toBe(false);
});

test("launcher setup refreshes account capabilities only when missing or explicitly requested", () => {
  const verifiedLauncher = {
    browserHost: "launcher",
    solAvailable: true,
    proAvailable: false,
  } as never;

  expect(launcherCapabilityProbeRequired(undefined)).toBe(true);
  expect(launcherCapabilityProbeRequired(verifiedLauncher)).toBe(false);
  expect(launcherCapabilityProbeRequired({
    browserHost: "launcher",
    proAvailable: false,
  } as never)).toBe(true);
  expect(launcherCapabilityProbeRequired(verifiedLauncher, true)).toBe(true);
});

test("standalone setup skips Codex integration and restart while the default plan remains integrated", () => {
  expect(setupIntegrationPlan({ standalone: true })).toEqual({
    usesCodexIntegration: false,
    replaceExistingRoute: false,
    codexRestartRequired: false,
  });
  expect(setupIntegrationPlan({ standalone: false, replaceCodexRoute: true })).toEqual({
    usesCodexIntegration: true,
    replaceExistingRoute: true,
    codexRestartRequired: true,
  });
  expect(() => setupIntegrationPlan({ standalone: true, replaceCodexRoute: true }))
    .toThrow("--replace-codex-route cannot be used with --standalone");
});
